import streamlit as st
import pandas as pd

st.title("Project Overview")

df = pd.read_csv("data/enhanced_final_detection_dataset.csv")

st.subheader("Project Description")

st.write("""
This project aims to detect suspicious Python packages
associated with software supply chain and dependency
confusion attacks using machine learning techniques.
""")

st.subheader("Dataset Summary")

col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Total Records", len(df))

with col2:
    st.metric("Features", len(df.columns))

with col3:
    st.metric("Classes", df["Label"].nunique())

st.subheader("Best Model")

st.success("Decision Tree Classifier")

st.write("""
Accuracy: 98.76%

Precision: 98.60%

Recall: 100.00%

F1-Score: 99.30%
""")